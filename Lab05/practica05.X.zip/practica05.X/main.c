////+++++++++++++++++++++++++++++++++++++| LIBRARIES / HEADERS |+++++++++++++++++++++++++++++++++++++
#include "device_config.h"
#include <math.h>
#include <xc.h>
#include <stdlib.h>
//+++++++++++++++++++++++++++++++++++++| DIRECTIVES |+++++++++++++++++++++++++++++++++++++
#define _XTAL_FREQ 1000000


//+++++++++++++++++++++++++++++++++++++| PORT NAMES |+++++++++++++++++++++++++++++++++++++
#define LED1 PORTAbits.RA0
#define LED2 PORTAbits.RA1
#define LED3 PORTAbits.RA2
#define LED4 PORTAbits.RA3
#define LED5 PORTAbits.RA4
#define LED6 PORTAbits.RA5
#define LED7 PORTAbits.RA6
#define LED8 PORTAbits.RA7

#define BUT1 PORTDbits.RD0
#define BUT2 PORTDbits.RD1
#define BUT3 PORTDbits.RD2
#define BUT4 PORTDbits.RD3
#define BUT5 PORTDbits.RD4
#define BUT6 PORTDbits.RD5
#define BUT7 PORTDbits.RD6
#define BUT8 PORTDbits.RD7

enum exponent {bbase = 2, limit = 8};

//+++++++++++++++++++++++++++++++++++++| ISRs |+++++++++++++++++++++++++++++++++++++
// ISR for high priority
void __interrupt ( high_priority ) high_isr( void );
// ISR for low priority
void __interrupt ( low_priority ) low_isr( void ); 

//+++++++++++++++++++++++++++++++++++++| FUNCTION DECLARATIONS |+++++++++++++++++++++++++++++++++++++
void portsInit( void );
void rider(void);
//+++++++++++++++++++++++++++++++++++++| MAIN |+++++++++++++++++++++++++++++++++++++
void main( void ){
    portsInit();
    
 
    while(1)
    {                                   
        //Encendido aleatorio de LEDs
        int aleatorio = rand()%limit;
        
        PORTA = pow(bbase, aleatorio);
        __delay_ms(300);
        
        // Revisar MATCH entre el LED y el BUTTON
        
        uint8_t boton = ~(PORTD);
        
        if (PORTA == boton)
        {
            rider();
        }
            
    }
    
}

//+++++++++++++++++++++++++++++++++++++| FUNCTIONS |+++++++++++++++++++++++++++++++++++++
void portsInit( void ){
    ANSELA = 0b00000000;                       // Set Port A as digital port
    TRISA = 0b00000000;                        // Set Port A as output
    PORTA = 0b00000000;                        //Set initial value on outputs = 0
    
    ANSELD = 0b00000000;                       // Set Port D as digital port
    TRISD = 0b11111111;                        // Set Port D as inputs
   
}

void rider (void){
    
    for(int i=0; i<=7; i=i++){
    PORTA = pow(bbase, i);
    __delay_ms(25);
    }
    
    for(int i=7; i>=0; i=i--){
    PORTA = pow(bbase, i);
    __delay_ms(25);
    }
    
}